import requests
from telegram import Bot, Update
from telegram.ext import Updater, CommandHandler, CallbackContext
import random
import time

# =========================
# CONFIGURATION
# =========================
BOT_TOKEN = "8266964842:AAGO-qTKf7c5DqcdlwlFmZERsB-1At7-s1g"
CHAT_ID = 6255890027
SSID = "ABEA8lzxo845NbfQ-"

# Example pairs and expiries
PAIRS = ["EURUSD", "GBPUSD", "USDJPY", "AUDUSD", "USDCAD"]
EXPIRY = ["1 min", "5 min", "15 min"]  # can adjust per pair

# Confidence threshold (we simulate 85-90% here)
CONFIDENCE_MIN = 85
CONFIDENCE_MAX = 90

bot = Bot(token=BOT_TOKEN)

# =========================
# FUNCTION TO GET SIGNAL
# =========================
def get_signal():
    # For now, we simulate signal logic with random choice
    pair = random.choice(PAIRS)
    direction = random.choice(["CALL", "PUT"])
    expiry = random.choice(EXPIRY)
    confidence = random.randint(CONFIDENCE_MIN, CONFIDENCE_MAX)
    
    signal_message = (
        f"PAIR: {pair}\n"
        f"DIRECTION: {direction}\n"
        f"EXPIRY: {expiry}\n"
        f"CONFIDENCE: {confidence}%\n"
        f"TIME: {time.strftime('%H:%M:%S')}"
    )
    return signal_message

# =========================
# TELEGRAM COMMAND HANDLER
# =========================
def send_signal(update: Update, context: CallbackContext):
    signal = get_signal()
    bot.send_message(chat_id=CHAT_ID, text=signal)

# =========================
# MAIN FUNCTION
# =========================
def main():
    updater = Updater(token=BOT_TOKEN, use_context=True)
    dispatcher = updater.dispatcher
    
    # Command to request signal
    dispatcher.add_handler(CommandHandler('signal', send_signal))
    
    # Start bot
    updater.start_polling()
    updater.idle()

if _name_ == "_main_":
    main()